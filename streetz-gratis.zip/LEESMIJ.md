# STREETZ – gratis online zetten (zonder server)

Dit is een gewone website-map. Er is geen server, geen terminal en geen installatie nodig.
Je beheert alles in `producten.xlsx`, en bestellingen komen als mail bij je binnen.

## Stap 1. Maak je bestelmail-sleutel (2 minuten)
1. Ga naar **web3forms.com** en vul `berend.steegstra@gmail.com` in (of het adres waar je bestellingen wilt ontvangen).
2. Je krijgt een mail met een **access key** (een lange code). Gratis, geen account nodig. Gratis plan: 250 bestellingen per maand.
3. Open `producten.xlsx`, tabblad **Instellingen**, en plak de code bij `web3forms_key`. Sla op.

## Stap 2. Zet de site online (5 minuten)
**Cloudflare Pages (mijn advies, gratis):**
1. Maak een gratis account op **cloudflare.com** en ga naar **Workers & Pages**.
2. Kies **Create application → Pages → Upload your static files** (ook wel "Drag and drop your files").
3. Geef een projectnaam (bijvoorbeeld `streetz`) en sleep **de map** (of de zip) erin. De bestanden moeten direct in de map staan, met `index.html` bovenaan.
4. Klik **Deploy**. Je site staat nu op `streetz.pages.dev`, met HTTPS (het slotje) erbij.

**Eigen domein (later, optioneel):** bij het project kun je onder *Custom domains* je eigen domein koppelen.

Liever **Netlify**? Dat kan ook: sleep de map op app.netlify.com/drop. Let op: bij nieuwe Netlify-accounts delen al je sites één maandelijks tegoed. Als dat op is, kan Netlify je sites pauzeren, ook tijdens een drukke drop.

## Stap 3. Testen
1. Open je site en doe een testbestelling op de Core Tee (testmodus staat aan, dus dat kan al).
2. Je krijgt een mail met het bestelnummer, de maat, het adres en de tekst *"Stuur een Tikkie van ... naar ..."*.
3. Komt er niets binnen? Kijk in je spam en controleer of de sleutel klopt.

---

## Dagelijks gebruik

### Producten of drops aanpassen
1. Pas `producten.xlsx` aan (tabblad **Uitleg** beschrijft elke kolom).
2. Sleep de map opnieuw naar Cloudflare: **project → Create a new deployment**. Klaar.

### Foto's
Zet de foto in de map `fotos/` (JPG of WebP, ongeveer 800 px breed, 4:5), schrijf de bestandsnaam in de Excel, en zet de map opnieuw online.

### Voorraad
De voorraad telt **niet** automatisch af. Je krijgt elke bestelling per mail, dus jij past het getal in de Excel aan. Tip: zet de voorraad iets lager dan wat je echt hebt, dan verkoop je nooit iets wat er niet is.

### Testmodus
Tabblad Instellingen, `testmodus`: **ja** = bestellen kan al vóór de release (met een gele sticker). **nee** = pas na de countdown. Zet hem op nee vóór je de link deelt.

### Lokaal bekijken
Dubbelklikken op `index.html` werkt niet (de Excel wordt dan geblokkeerd). Open een terminal in de map en typ `python3 -m http.server 8000`, ga dan naar http://localhost:8000.

---

## Voor je live gaat
- [ ] `web3forms_key` ingevuld en testbestelling gedaan.
- [ ] `testmodus` op `nee`.
- [ ] De foto `voorbeeld-core-tee.jpg` is van Uniqlo (alleen om te testen). Vervang door je eigen foto's.
- [ ] Privacyverklaring (`privacy.html`): vul de roze velden in en laat de tekst controleren. Je verwerkt gegevens van minderjarigen.
- [ ] Voorwaarden voor webwinkels (herroepingsrecht van 14 dagen, retour, bedrijfsgegevens, levertijd) staan er nog niet in. Raadpleeg Consuwijzer of een jurist.
- [ ] Wil je dat Google de site vindt? Verwijder in `index.html` de regel met `noindex`.

## Goed om te weten
- **De sleutel is niet geheim.** Hij staat in de Excel en dus in je site. Iemand kan er in theorie spam mee versturen. Web3Forms filtert spam, en bij misbruik vraag je gewoon een nieuwe sleutel aan.
- **Het bedrag wordt in de browser berekend.** Jij controleert elke bestelling in je mail voordat je een Tikkie stuurt, dus dit is geen risico.
- **Betalen blijft handmatig** met een Tikkie. Automatische betaling (iDEAL) kan later.
- **Twee mensen kunnen tegelijk het laatste stuk bestellen**, omdat er geen server is die telt. Dan stuur je één van hen een bericht.
