(() => {
'use strict';

/* ============================================================
   Hulpjes
   ============================================================ */
const $ = id => document.getElementById(id);
const SVGNS = 'http://www.w3.org/2000/svg';
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v === null || v === undefined) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat().forEach(c => { if (c !== null && c !== undefined) e.append(c); });
  return e;
}
const eur2 = n => '€' + n.toFixed(2).replace('.', ',');
const eur = n => (Number.isInteger(n) ? '€' + n : eur2(n));
const pad = n => String(n).padStart(2, '0');
const LOGO = '/img/logo.webp';
const WEB3FORMS = 'https://api.web3forms.com/submit';

const state = { cat: null, skew: 0, active: null, live: false, released: false, lastFetch: 0 };
const now = () => Date.now() + state.skew;

function toast(msg) {
  const t = $('toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('on'), 2400);
}
const store = {
  get(k) { try { return localStorage.getItem('streetz_' + k) || ''; } catch (e) { return ''; } },
  set(k, v) { try { localStorage.setItem('streetz_' + k, v); } catch (e) { /* privé modus: negeren */ } }
};

/* ============================================================
   Excel (producten.xlsx) lezen en opschonen
   ============================================================ */
const str = v => (v === undefined || v === null ? '' : String(v)).trim();
const isYes = (v, standaard) => {
  const s = str(v).toLowerCase();
  if (!s) return !!standaard;
  return ['ja', 'yes', 'true', '1', 'j', 'y', 'waar'].includes(s);
};
function num(v) {
  if (typeof v === 'number') return v;
  let s = str(v).replace(/[€\s]/g, '');
  if (!s) return NaN;
  if (s.includes(',') && s.includes('.')) s = s.replace(/\./g, '').replace(',', '.');
  else s = s.replace(',', '.');
  return /^-?\d+(\.\d+)?$/.test(s) ? parseFloat(s) : NaN;
}
const dropKey = v => { const s = str(v); return /^\d+$/.test(s) ? String(parseInt(s, 10)) : s.toLowerCase(); };

/* Nederlandse tijd -> echte tijdstip, inclusief zomer-/wintertijd */
const amsFmt = new Intl.DateTimeFormat('en-US', { timeZone: 'Europe/Amsterdam', hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
function amsOffset(ts) {
  const p = Object.fromEntries(amsFmt.formatToParts(new Date(ts)).map(x => [x.type, x.value]));
  return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - Math.floor(ts / 1000) * 1000;
}
function amsterdamToEpoch(y, mo, d, h, mi) {
  const guess = Date.UTC(y, mo - 1, d, h, mi);
  let t = guess - amsOffset(guess);
  t = guess - amsOffset(t);
  return t;
}
function parseRelease(v) {
  if (v === '' || v === null || v === undefined) return null;
  let y, mo, d, hh = 0, mi = 0, sec = 0;
  if (typeof v === 'number') {                         // Excel-datum (serienummer)
    const dt = new Date(Math.round((v - 25569) * 86400) * 1000);
    y = dt.getUTCFullYear(); mo = dt.getUTCMonth() + 1; d = dt.getUTCDate(); hh = dt.getUTCHours(); mi = dt.getUTCMinutes();
  } else {
    const s = str(v);
    let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T]+(\d{1,2})[:.](\d{2})(?::(\d{2}))?)?/);
    if (m) { y = +m[1]; mo = +m[2]; d = +m[3]; hh = +(m[4] || 0); mi = +(m[5] || 0); sec = +(m[6] || 0); }
    else {
      m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})(?:[ T]+(\d{1,2})[:.](\d{2}))?/);
      if (!m) return NaN;
      d = +m[1]; mo = +m[2]; y = +m[3]; hh = +(m[4] || 0); mi = +(m[5] || 0);
    }
  }
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || hh > 23 || mi > 59) return NaN;
  return amsterdamToEpoch(y, mo, d, hh, mi) + sec * 1000;
}
const FOTO_RE = /^[\w][\w.\- ]*\.(jpe?g|png|webp|avif|gif)$/i;

function parseWorkbook(wb) {
  const warnings = [], warn = m => warnings.push(m);
  const rows = name => wb.Sheets[name] ? XLSX.utils.sheet_to_json(wb.Sheets[name], { defval: '', raw: true }) : null;

  const settings = {
    merknaam: 'STREETZ', verzendkosten: 4.95, testmodus: false, bestel_email: '', web3forms_key: '',
    ticker: 'KLEINE OPLAGE   //   GEEN HERDRUK', hero_regel_1: 'Not for', hero_regel_2: 'everyone',
    footer_tekst: 'Kleine oplagen. Als hij weg is, is hij weg.'
  };
  const sRows = rows('Instellingen');
  if (!sRows) warn('Tabblad "Instellingen" ontbreekt: standaardwaarden gebruikt.');
  else {
    const kv = {};
    sRows.forEach(r => { const k = str(r.sleutel).toLowerCase(); if (k) kv[k] = r.waarde; });
    for (const k of ['merknaam', 'bestel_email', 'web3forms_key', 'ticker', 'hero_regel_1', 'hero_regel_2', 'footer_tekst'])
      if (kv[k] !== undefined && str(kv[k]) !== '') settings[k] = str(kv[k]);
    if (kv.verzendkosten !== undefined && str(kv.verzendkosten) !== '') {
      const n = num(kv.verzendkosten);
      if (Number.isFinite(n) && n >= 0) settings.verzendkosten = Math.round(n * 100) / 100;
      else warn('verzendkosten is geen geldig bedrag: 4,95 gebruikt.');
    }
    settings.testmodus = isYes(kv.testmodus, false);
  }

  const dRows = rows('Drops');
  if (!dRows) throw new Error('Tabblad "Drops" ontbreekt in producten.xlsx');
  const drops = [], dropByKey = new Map();
  dRows.forEach((r, i) => {
    const nummer = str(r.nummer);
    if (!nummer) { if (Object.values(r).some(v => str(v))) warn(`Drops regel ${i + 2}: nummer ontbreekt, regel overgeslagen.`); return; }
    const key = dropKey(nummer);
    if (dropByKey.has(key)) { warn(`Drops: nummer ${nummer} komt dubbel voor, tweede regel overgeslagen.`); return; }
    let release = parseRelease(r.release_datum);
    if (Number.isNaN(release)) { warn(`Drops ${nummer}: release_datum "${str(r.release_datum)}" is niet te lezen (gebruik jjjj-mm-dd uu:mm). Drop telt als al verschenen.`); release = null; }
    else if (release === null) warn(`Drops ${nummer}: geen release_datum ingevuld. Drop telt als al verschenen.`);
    const drop = { key, nummer, naam: str(r.naam) || ('Drop ' + (/^\d+$/.test(nummer) ? nummer.padStart(3, '0') : nummer)), release, omschrijving: str(r.omschrijving), producten: [] };
    drops.push(drop); dropByKey.set(key, drop);
  });

  const pRows = rows('Producten');
  if (!pRows) throw new Error('Tabblad "Producten" ontbreekt in producten.xlsx');
  const seen = new Set();
  pRows.forEach((r, i) => {
    const regel = i + 2, naam = str(r.naam);
    if (!naam && !str(r.drop)) return;
    if (!naam) { warn(`Producten regel ${regel}: naam ontbreekt, overgeslagen.`); return; }
    if (!isYes(r.zichtbaar, true)) return;
    const drop = dropByKey.get(dropKey(r.drop));
    if (!drop) { warn(`Producten regel ${regel} (${naam}): drop "${str(r.drop)}" bestaat niet op het tabblad Drops, overgeslagen.`); return; }
    const prijs = num(r.prijs);
    if (!Number.isFinite(prijs) || prijs <= 0) { warn(`Producten regel ${regel} (${naam}): prijs "${str(r.prijs)}" is ongeldig, overgeslagen.`); return; }
    const id = drop.key + '|' + naam.toLowerCase();
    if (seen.has(id)) { warn(`Producten regel ${regel}: "${naam}" staat dubbel in drop ${drop.nummer}, overgeslagen.`); return; }
    seen.add(id);
    let maten = [...new Set(str(r.maten).split(',').map(s => s.trim()).filter(Boolean))];
    if (!maten.length) maten = ['One size'];
    let voorraad = num(r.voorraad);
    if (!Number.isFinite(voorraad) || voorraad < 0) { warn(`Producten regel ${regel} (${naam}): voorraad "${str(r.voorraad)}" is ongeldig, op 0 gezet.`); voorraad = 0; }
    let kleur = str(r.kleur);
    if (!/^#[0-9a-f]{6}$/i.test(kleur)) { if (kleur) warn(`Producten regel ${regel} (${naam}): kleur "${kleur}" is geen hex-kleur (bijv. #D2FF1F).`); kleur = '#6B4DFF'; }
    let foto = str(r.foto);
    if (foto && !FOTO_RE.test(foto)) { warn(`Producten regel ${regel} (${naam}): foto "${foto}" is geen geldige bestandsnaam. Silhouet gebruikt.`); foto = ''; }
    const pct = (v, d) => { const n = num(v); return Number.isFinite(n) ? Math.min(100, Math.max(0, n)) : d; };
    drop.producten.push({
      id, naam, prijs: Math.round(prijs * 100) / 100, kleur, maten, over: Math.floor(voorraad),
      tekst: str(r.tekst), details: str(r.details), foto,
      logo: !!foto && isYes(r.logo_op_foto, false),
      logo_x: pct(r.logo_x, 46), logo_y: pct(r.logo_y, 52), logo_breedte: Math.max(5, pct(r.logo_breedte, 34))
    });
  });
  drops.forEach(d => { if (!d.producten.length) warn(`Drop ${d.nummer} heeft geen zichtbare producten.`); });
  return { settings, drops, warnings };
}

/* ============================================================
   Laden
   ============================================================ */
async function load(silent) {
  try {
    const r = await fetch('/producten.xlsx?v=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('producten.xlsx: status ' + r.status);
    const buf = await r.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const cat = parseWorkbook(wb);
    const serverDate = Date.parse(r.headers.get('Date') || '');
    state.skew = Number.isFinite(serverDate) ? serverDate - Date.now() : 0;   // klok van de bezoeker kan afwijken
    cat.warnings.forEach(w => console.warn('[excel] ' + w));
    state.cat = cat; state.lastFetch = Date.now();
    render();
  } catch (e) {
    console.error(e);
    if (silent && state.cat) return;
    const s = $('status');
    s.textContent = 'De drop kon niet worden geladen. Controleer je internet en probeer het opnieuw. ';
    s.append(h('button', { class: 'btn', type: 'button', onclick: () => { $('status').textContent = 'Laden…'; load(); } }, 'Opnieuw proberen'));
    $('grid').textContent = '';
  }
}

function pickActive(cat) {
  const t = now();
  const upcoming = cat.drops.filter(d => d.release && d.release > t).sort((a, b) => a.release - b.release);
  if (upcoming.length) return upcoming[0];
  return [...cat.drops].sort((a, b) => (b.release || 0) - (a.release || 0))[0] || null;
}
const dropReleased = d => !d.release || d.release <= now();
const dropLive = d => state.cat.settings.testmodus || dropReleased(d);

/* ============================================================
   Productkaart
   ============================================================ */
function silhouette(p) {
  const w = p.naam.toUpperCase().split(/\s+/);
  const svg = document.createElementNS(SVGNS, 'svg');
  svg.setAttribute('viewBox', '0 0 200 220'); svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', p.naam);
  const mk = (n, a) => { const e = document.createElementNS(SVGNS, n); for (const k in a) e.setAttribute(k, a[k]); return e; };
  svg.append(
    mk('path', { d: 'M60 20 L85 14 Q100 36 115 14 L140 20 L192 58 L170 100 L148 84 L148 206 L52 206 L52 84 L30 100 L8 58 Z', fill: p.kleur, stroke: '#0A0A0B', 'stroke-width': 3, 'stroke-linejoin': 'round' }),
    mk('path', { d: 'M85 14 Q100 36 115 14', fill: 'none', stroke: '#0A0A0B', 'stroke-width': 3 })
  );
  const t1 = mk('text', { x: 100, y: 108, 'text-anchor': 'middle', 'font-family': 'Anton,Impact,sans-serif', 'font-size': 30, fill: '#0A0A0B' }); t1.textContent = w[0] || '';
  const t2 = mk('text', { x: 100, y: 140, 'text-anchor': 'middle', 'font-family': 'Anton,Impact,sans-serif', 'font-size': 30, fill: 'none', stroke: '#0A0A0B', 'stroke-width': 1.5 }); t2.textContent = w.slice(1).join(' ');
  svg.append(t1, t2);
  return svg;
}

function card(drop, p) {
  const sold = p.over <= 0, live = dropLive(drop);
  const pic = h('div', { class: 'pic' });
  pic.style.setProperty('--c', p.kleur);
  if (p.foto) {
    const img = h('img', { class: 'foto', src: '/fotos/' + encodeURIComponent(p.foto), alt: p.naam, loading: 'lazy', decoding: 'async' });
    let lg = null;
    img.addEventListener('error', () => { img.remove(); if (lg) lg.remove(); pic.prepend(silhouette(p)); });   // foto bestaat niet: toon silhouet
    pic.append(img);
    if (p.logo) {
      lg = h('div', { class: 'logo-on' }, h('img', { src: LOGO, alt: '' }));
      lg.style.left = p.logo_x + '%'; lg.style.top = p.logo_y + '%'; lg.style.width = p.logo_breedte + '%';
      pic.append(lg);
    }
  } else pic.append(silhouette(p));
  pic.append(
    h('div', { class: 'stock', text: sold ? 'sold out' : (p.over <= 15 ? 'nog ' + p.over : p.over + ' stuks') }),
    h('div', { class: 'stamp', 'aria-hidden': 'true' }, h('b', { text: 'SOLD OUT' }))
  );
  const sizes = h('div', { class: 'sizes', role: 'group', 'aria-label': 'Kies je maat' });
  p.maten.forEach(m => sizes.append(h('button', { type: 'button', disabled: sold || !live, 'aria-label': 'Maat ' + m + ', bestel direct', onclick: () => openOrder(drop, p, m) }, m)));
  let label = 'Bestel nu', off = false;
  if (sold) { label = 'Sold out'; off = true; } else if (!live) { label = 'Binnenkort live'; off = true; }
  const btn = h('button', { class: 'btn' + (off ? ' off' : ''), type: 'button', disabled: off, onclick: () => openOrder(drop, p, p.maten.length === 1 ? p.maten[0] : null) }, label);
  return h('article', { class: 'card' + (sold ? ' sold' : '') }, pic,
    h('div', { class: 'info' },
      h('div', { class: 'row' }, h('h3', { text: p.naam }), h('span', { text: eur(p.prijs) })),
      p.tekst ? h('p', { text: p.tekst }) : null,
      p.details ? h('p', { class: 'det', text: p.details }) : null,
      sizes, btn));
}

/* ============================================================
   Pagina opbouwen
   ============================================================ */
function fmtRelease(ts) {
  const d = new Date(ts);
  const dag = d.toLocaleDateString('nl-NL', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'Europe/Amsterdam' });
  const tijd = d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Amsterdam' });
  return dag + ' om ' + tijd;
}
function render() {
  const cat = state.cat, S = cat.settings;
  document.title = S.merknaam + ' – exclusieve drops';
  $('tickerText').textContent = (S.ticker + '   //   ').repeat(8);
  $('h1a').textContent = S.hero_regel_1; $('h1b').textContent = S.hero_regel_2;
  $('footBrand').textContent = S.merknaam; $('footText').textContent = S.footer_tekst;
  $('testSticker').hidden = !S.testmodus;
  const drop = pickActive(cat); state.active = drop;
  const status = $('status'), grid = $('grid'); grid.textContent = '';
  if (!drop) {
    status.textContent = 'Er staat nog geen drop klaar. Kom snel terug.';
    $('heroSticker').textContent = 'Binnenkort'; $('dropTitle').textContent = 'Binnenkort';
    $('dropSub').textContent = ''; $('heroText').textContent = ''; $('count').hidden = true;
    $('archief').hidden = true; $('navArchief').hidden = true;
    return;
  }
  status.textContent = '';
  state.live = dropLive(drop); state.released = dropReleased(drop);
  $('dropTitle').textContent = drop.naam;
  $('heroSticker').textContent = state.released ? 'Live nu' : drop.naam;
  drop.producten.forEach(p => grid.append(card(drop, p)));
  if (!drop.producten.length) status.textContent = 'In deze drop staan nog geen producten.';
  const rest = cat.drops.filter(d => d !== drop && d.producten.length).sort((a, b) => (b.release || 0) - (a.release || 0));
  const lijst = $('archiefList'); lijst.textContent = '';
  rest.forEach(d => {
    const g = h('div', { class: 'grid' }); d.producten.forEach(p => g.append(card(d, p)));
    lijst.append(h('h3', { class: 'dn', text: d.naam }), d.release ? h('p', { class: 'sub', text: 'Release ' + fmtRelease(d.release) }) : null, g);
  });
  $('archief').hidden = !rest.length; $('navArchief').hidden = !rest.length;
  tick();
}
function tick() {
  const drop = state.active; if (!drop || !state.cat) return;
  const diff = drop.release ? drop.release - now() : 0;
  if (diff <= 0 && !state.released) { state.released = true; load(true); }
  if (diff > 0) {
    const s = Math.floor(diff / 1000);
    $('count').hidden = false;
    $('cd-d').textContent = pad(Math.floor(s / 86400)); $('cd-h').textContent = pad(Math.floor(s % 86400 / 3600));
    $('cd-m').textContent = pad(Math.floor(s % 3600 / 60)); $('cd-s').textContent = pad(s % 60);
    $('heroText').textContent = drop.omschrijving;
    $('dropSub').textContent = 'Release ' + fmtRelease(drop.release);
    $('heroBtn').textContent = 'Bekijk de drop';
  } else {
    $('count').hidden = true;
    $('heroText').textContent = drop.omschrijving || 'De drop is open. Pak je maat voordat hij weg is.';
    $('dropSub').textContent = drop.producten.some(p => p.over > 0) ? 'Live. Pak je maat voordat hij weg is.' : 'Alles is sold out.';
    $('heroBtn').textContent = 'Naar de drop';
  }
}

/* ============================================================
   Bestelformulier
   ============================================================ */
const dlg = $('order'), form = $('orderForm'), done = $('oDone');
const FIELDS = ['naam', 'mobiel', 'straat', 'postcode', 'plaats'];
let huidig = null, bezig = false;

function toonSom() {
  const { p, maat } = huidig, v = state.cat.settings.verzendkosten;
  const rij = (a, b, c) => h('div', { class: c || '' }, h('span', { text: a }), h('span', { text: b }));
  $('oSum').textContent = '';
  $('oSum').append(rij(p.naam + (maat ? ' · maat ' + maat : ''), eur2(p.prijs)), rij('Verzending', eur2(v)), rij('Totaal', eur2(p.prijs + v), 'tot'));
  $('oSizes').querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.textContent === maat)));
}
function openOrder(drop, p, maat) {
  if (!dropLive(drop) || p.over <= 0) return;
  huidig = { drop, p, maat };
  form.hidden = false; done.hidden = true; $('oErr').textContent = '';
  form.querySelectorAll('input').forEach(i => i.classList.remove('bad'));
  const zs = $('oSizes'); zs.textContent = '';
  p.maten.forEach(m => zs.append(h('button', { type: 'button', onclick: () => { huidig.maat = m; $('oErr').textContent = ''; toonSom(); } }, m)));
  FIELDS.forEach(n => { if (!form.elements[n].value) form.elements[n].value = store.get(n); });
  toonSom();
  $('oSend').disabled = false; $('oSend').textContent = 'Bestel nu'; bezig = false;
  if (!dlg.open) dlg.showModal();
}
$('oClose').addEventListener('click', () => dlg.close());
dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
form.addEventListener('input', e => { e.target.classList.remove('bad'); });

const clean = (v, max) => str(v).replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
function normMobiel(v) { const m = str(v).replace(/[\s\-().]/g, '').match(/^(?:\+31|0031|0)(6\d{8})$/); return m ? '0' + m[1] : null; }
function normPostcode(v) { const m = str(v).match(/^([1-9]\d{3})\s?([A-Za-z]{2})$/); return m ? m[1] + ' ' + m[2].toUpperCase() : null; }
function bestelId() {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', a = new Uint8Array(6);
  if (self.crypto && crypto.getRandomValues) crypto.getRandomValues(a); else a.forEach((_, i) => { a[i] = Math.floor(Math.random() * 256); });
  return Array.from(a, b => abc[b % abc.length]).join('');
}
const fieldMsg = {
  naam: 'Vul je naam in.', mobiel: 'Vul een mobiel nummer in, zoals 06 12345678.',
  straat: 'Vul straat en huisnummer in, bijvoorbeeld Dorpsstraat 12.', postcode: 'Vul je postcode in, zoals 1234 AB.', plaats: 'Vul je plaats in.'
};
function checkForm() {
  const f = form.elements, bad = [];
  const mark = (n, isBad) => { f[n].classList.toggle('bad', isBad); if (isBad) bad.push(n); };
  mark('naam', clean(f.naam.value, 80).length < 2);
  mark('mobiel', !normMobiel(f.mobiel.value));
  mark('straat', clean(f.straat.value, 100).length < 4 || !/\d/.test(f.straat.value));
  mark('postcode', !normPostcode(f.postcode.value));
  mark('plaats', clean(f.plaats.value, 60).length < 2);
  return bad;
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  if (bezig || !huidig) return;
  if (!huidig.maat) { $('oErr').textContent = 'Kies eerst je maat.'; const b = $('oSizes').querySelector('button'); if (b) b.focus(); return; }
  const bad = checkForm();
  if (bad.length) { $('oErr').textContent = fieldMsg[bad[0]]; form.elements[bad[0]].focus(); return; }
  if (form.elements.website.value) { toonKlaar({ id: 'XXXXXX', totaal: 0, mobiel: '' }); return; }   // bot: nep-succes

  const S = state.cat.settings, { p, maat } = huidig, f = form.elements;
  if (!S.web3forms_key) { $('oErr').textContent = 'Bestellen is nog niet ingesteld. Probeer het later opnieuw.'; return; }

  const totaal = Math.round((p.prijs + S.verzendkosten) * 100) / 100;
  const order = {
    Bestelnummer: bestelId(), Product: p.naam + ' (maat ' + maat + ')', Drop: huidig.drop.nummer,
    Prijs: eur2(p.prijs), Verzending: eur2(S.verzendkosten), Totaal: eur2(totaal),
    Naam: clean(f.naam.value, 80), Mobiel: normMobiel(f.mobiel.value),
    Adres: clean(f.straat.value, 100) + ', ' + normPostcode(f.postcode.value) + ' ' + clean(f.plaats.value, 60),
    Actie: 'Stuur een Tikkie van ' + eur2(totaal) + ' naar ' + normMobiel(f.mobiel.value),
    Besteld: new Date(now()).toLocaleString('nl-NL', { timeZone: 'Europe/Amsterdam' })
  };

  bezig = true; $('oErr').textContent = ''; $('oSend').disabled = true; $('oSend').textContent = 'Versturen...';
  let ok = false, reden = '';
  try {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 20000);
    const res = await fetch(WEB3FORMS, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, signal: ctl.signal,
      body: JSON.stringify({ access_key: S.web3forms_key, subject: 'Nieuwe bestelling #' + order.Bestelnummer + ': ' + order.Product + ' ' + order.Totaal, from_name: S.merknaam + ' shop', ...order })
    });
    clearTimeout(to);
    const data = await res.json();
    ok = !!(data && data.success);
    if (!ok) reden = (data && data.message) || '';
  } catch (err) { reden = 'netwerk'; }

  if (ok) {
    FIELDS.forEach(n => store.set(n, f[n].value.trim()));
    toonKlaar({ id: order.Bestelnummer, totaal, mobiel: order.Mobiel }, p, maat);
    return;
  }
  bezig = false; $('oSend').disabled = false; $('oSend').textContent = 'Bestel nu';
  const msg = $('oErr');
  msg.textContent = reden === 'netwerk' ? 'Geen verbinding. Probeer het opnieuw. ' : 'Versturen lukte niet. Probeer het opnieuw. ';
  if (S.bestel_email) {
    const body = Object.entries(order).map(([k, v]) => k + ': ' + v).join('\n');
    msg.append('Lukt het niet? ', h('a', { href: 'mailto:' + S.bestel_email + '?subject=' + encodeURIComponent('Bestelling ' + order.Product) + '&body=' + encodeURIComponent(body) }, 'Stuur je bestelling via mail'), '.');
  }
});
function toonKlaar(r, p, maat) {
  form.hidden = true; done.hidden = false; done.textContent = '';
  done.append(
    h('h2', { text: 'Bestelling binnen' }),
    h('p', {}, 'Bestelnummer ', h('b', { text: '#' + r.id }), '.'),
    h('p', {}, 'Je krijgt een Tikkie van ', h('b', { text: eur2(r.totaal) }), ' op ', h('b', { text: r.mobiel }), p ? '. Zodra die betaald is, sturen we je ' + p.naam + ' (maat ' + maat + ') op.' : '.'),
    h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Sluiten'));
}

/* ============================================================
   Start
   ============================================================ */
setInterval(tick, 1000);
setInterval(() => { if (!document.hidden && state.cat && state.live && Date.now() - state.lastFetch > 30000 && !dlg.open) load(true); }, 15000);
document.addEventListener('visibilitychange', () => { if (!document.hidden && state.cat && Date.now() - state.lastFetch > 20000 && !dlg.open) load(true); });
load();
})();
